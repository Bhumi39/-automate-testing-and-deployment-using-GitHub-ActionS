import React from "react";

function App() {
  return (
    <div className="App">
      <h1>React App Dockerized Successfully 🚀</h1>
      <p>This React application is running inside a Docker container using a multi-stage build.</p>
    </div>
  );
}

export default App;
